import flask
from flask import jsonify, request
from txtai.app import Application
import json
import pandas as pd

application = flask.Flask(__name__)
embeddings = Application('config.yml')
df = pd.read_csv('api-data.csv')


@application.route('/', methods=['GET'])
def home():
    return "<h1>Distant Reading Archive</h1><p>This site is a prototype API for distant reading of science fiction novels.</p>"


@application.route('/batchsearch')
def batchSearch():
    api_info = []  # create an empty dictionary to store the API info
    queries = list(request.args.get('queries').split(','))
    filter_list = ['APIS', 'Api', 'aPi', 'API\'s', 'apis', 'APIs', 'api', 'API', 'api\'s']
    for word in filter_list:
        queries = [x.replace(word, '') for x in queries]
    res = embeddings.batchsearch(queries)
    print(queries)
    for api in res[0]:
        if api['score'] > float(request.args.get('threshold')):
            to_append = df.iloc[[api['id']]].to_json(orient='records')
            to_append_dict = json.loads(to_append)[0]
            if to_append_dict['Id'] == 'a00DM00000E7YnOYAV':
                to_append_dict['API_ENDPOINT'] = 'GET / account'
                to_append_dict['API_URL'] = 'https://anypoint.mulesoft.com/mocking/api/v1/links/28cfbdf9-717f-42f8-a9d6-283e66c9f6af/financial-account-lookup/account?accountNumber=1'
            else:
                to_append_dict['API_ENDPOINT'] = None
                to_append_dict['API_URL'] = None

            if to_append_dict['Id'] != 'a00f000000EB7fBAAT' and to_append_dict['Id'] != 'a00DM00000E8ZmzYAF':
                api_info.append(to_append_dict)
    return api_info


if __name__ == '__main__':
    application.run()
